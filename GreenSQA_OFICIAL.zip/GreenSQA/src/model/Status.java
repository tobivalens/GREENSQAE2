package model;

public enum Status {
    POR_DEFINIR, APPROVED, NOT_APPROVED;
}
