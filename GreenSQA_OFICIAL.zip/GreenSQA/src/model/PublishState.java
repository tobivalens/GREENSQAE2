package model;

public enum PublishState {
    PUBLISHED, NOT_PUBLISHED;
}
