package model;

public enum  Type {
    TECHNICIAN,EXPERIENCES, MANAGEMENT, DOMAIN;
}
